import type { ReactNode } from "react"
import { Sidebar } from "../ui/sidebar"
import Header from "./Header"
import Footer from "./Footer"

interface DashboardLayoutProps {
  children: ReactNode
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <div className="flex w-full flex-col md:ml-20 lg:ml-64">
        <Header />
        <main className="flex-1 p-4 md:p-6">{children}</main>
        <Footer />
      </div>
    </div>
  )
}
